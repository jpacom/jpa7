	<div id="services">
		<div class="pages-navigation-bar">
			<div>شما اینجا هستید &gt; <a class="smallerLatin" href="/">JPA</a> &gt; خدمات &gt; <a href="/software-services">خدمات نرم افزاری</a></div>
		</div>
		<div id="pages-main">
			<!-- <div class="banner">&nbsp;</div> -->
			<div class="main-text">
                <div class="title">خدمات شرکت</div>
                <div>
                    <div class="tumbnail_image left_float" style="background-image: url(&quot;http://<?php echo $basedomain; ?>/inc/images/services/software.jpg&quot;);position:relative;width:400px;height:250px;background-repeat:no reapeat;margin-top:60px;margin-right:15px;"></div>
                    <p class="title_h2">خدمات نرم افزاری</p>
                    <p style="margin: 0px;">یکی از اهداف شرکت جهان پردازش البرز طراحی سایت های حرفه ای با هزینه ای پایین برای ارتقای سطح تبلیغاتی ، بازاریابی و جذب مشتری ، دسترسی آسان به کارایی و محصولات شما ، ارتباط با تمام نقاط جهان و قابلیت های فراوان دیگر سایت می باشد.</br>
                    اگر می خواهید وب سایت جدید خود را راه اندازی کنید و در ابتدای کار خود هستید حتما با ما تماس بگیرید چون می تواند تحارت شما را متحول کند. پیاده سازی سایت به یک تخصص نیاز دارد. در صورتی که می خواید در زمینه کاری خود موفق باشید به ما ملحق شوید ...</br>
                    از خدمات نرم افزاری شرکت جهان پردازش البرز می توان به موارد زیر اشاره کرد:

                    <ul class="list">
                    <li>•   طراحی و برنامه نویسی انواع سایت و پورتال پایه، خبری و فروشگاهی به زبانهای قدرتمند PHP، HTML5، CSS و JavaScript</li>
                    <li>•   خدمات هاستینگ در زمینه های هاست اشتراکی، سرور مجازی و سرور اختصاصی </li>
                    <li>•   ثبت دامنه</li>
                    <li>•   اتوماسیون اداری</li>
                    <li>•   طراحی برنامه های کاربردی موبایل و نرم افزارهای کامپیوتری</li>
                    <li>•   طرحی بازی رایانه ای</li>
                    <li>•   هوشمند سازی </li>
                    <li>•   پردازش تصاویر پزشکی</li>
                    <li>•   ساخت و تولید انیمیشن </li>
                    <li>•   ساخت و تولید تیزر تبلیغاتی و  ......</li>
                   
                    </ul>
                   
                    
                </div>
                
                    <p class="contactbox">برای اطلاعات بیشتر و کسب مشاوره از متخصصین ما با شماره تلفن های 02632209627 و 02632211861 تماس حاصل فرمایید.</p>
                
                <div style="clear: both;height: 10px;"></div>

            </div>




        </div>



    </div>



